
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row mt-5">
            <div class="col-md-12">
                <h3>Dear Customer,
                <p>You successfully submitted the following products.Thanks for your shopping here</p>
            </div>
        </div>
        <div class="row"> 
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-center text-white">Customer's Information</div>
                    <div class="card-body">
                        <table class="table table-hover">
                            <tr>
                                <td>Customer Name</td>
                                <td>Rain</td>
                            </tr>
                            <tr>
                                <td>Customer Phone</td>
                                <td>098887699</td>
                            </tr>
                            <tr>
                                <td>Customer Address</td>
                                <td>Yangon</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-success text-center text-white">Order Information</div>
                    <div class="card-body">
                        <table class="table table-hover">
                            <tr>
                                <td>Product Name</td>
                                <td>Unit Price</td>
                                <td>Quantity</td>
                                <td>Price</td>
                            </tr>
                                <td>Jeans Pant</td>
                                <td>20000</td>
                                <td>3</td>
                                <td>60000</td>
                            <tr>

                            </tr>
                                <td>Jeans Pant</td>
                                <td>20000</td>
                                <td>3</td>
                                <td>60000</td>
                            <tr>
                                <td colspan="3" align="right">Total Amount</td>
                                <td>60000</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>